# Readme for Task-5

## Run command
Make sure you are running your script on the Linux machine

    $ bash solution-5.sh http://127.0.0.1:55005/sample_data.tar

## How to test?

Check your `result.txt` if it follows the output format. 

Check your `smart/` directory and `OS/` directory if they contain the
desired files.


## Clean command

    $ make clean
