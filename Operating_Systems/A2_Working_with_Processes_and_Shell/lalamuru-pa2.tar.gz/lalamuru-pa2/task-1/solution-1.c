/* Your code goes here */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(int arg_count, char *args[])
{
    char error_msg[] = "An error has occurred\n";
    char *command_arguments[4];

    // check for argument count
    if(arg_count != 2) {
        fprintf(stderr, "%s" ,error_msg);
        exit(1);
    }

    FILE *fp;
    fp = fopen(args[1],"r");
    if(fp == NULL) {
        fprintf(stderr ,"%s" ,error_msg);
        exit(1);
    }

    char buffer[1024];
    // Read and execute all lines from file
    while(fgets(buffer, sizeof(buffer), fp)) {
        // Removing newline character
        buffer[strcspn(buffer, "\n")] = 0;
        command_arguments[0] = strtok(buffer, " ");
        for(int i = 1; i < 4; i++) {
            command_arguments[i] = strtok(NULL, " ");
            if (command_arguments[i] == NULL) 
	    {
		break;
	    }
        }

	pid_t pid;
	int status;

        //fork the new process
        pid = fork();
        if(pid == -1) {
            fprintf(stderr, "%s" ,error_msg);
            exit(1);
        }
        // handle the child process
	else if(pid == 0)
	{
		if(execvp(command_arguments[0], command_arguments) == -1)
		{
			fprintf(stderr, "%s", error_msg);
			exit(-1);
		}
	}

        //make wait the Parent process until child process returns
	else
       	{

            if(waitpid(pid, &status, 0) == -1) {
                fprintf(stderr, "%s" ,error_msg);
                exit(1);
            }

            if(!WIFEXITED(status) || WEXITSTATUS(status) != 0) {
                fprintf( stderr , "%s" ,error_msg);
                exit(1);
            }

        }
    }
    
    fclose(fp);
    return 0;
}
