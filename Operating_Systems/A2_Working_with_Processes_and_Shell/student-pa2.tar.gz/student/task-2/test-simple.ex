tinyshell> /bin/cat
tinyshell> /usr/bin/ps
tinyshell> /bin/false
tinyshell>   8  17 106 ./test-simple.in
tinyshell> tinyshell> /tmp
tinyshell> Usage: /bin/true [ignored command line arguments]
  or:  /bin/true OPTION
Exit with a status code indicating success.

      --help     display this help and exit
      --version  output version information and exit

NOTE: your shell may have its own version of true, which usually supersedes
the version described here.  Please refer to your shell's documentation
for details about the options it supports.

GNU coreutils online help: <https://www.gnu.org/software/coreutils/>
Full documentation at: <https://www.gnu.org/software/coreutils/true>
or available locally via: info '(coreutils) true invocation'
tinyshell> 