import requests
import time

# OpenWeatherMap setup
weather_api_key = "f4a69c175e939c5d65a0b4b560e1bed4"
city = "Syracuse,US"
weather_url = f"https://api.openweathermap.org/data/2.5/weather?q={city}&appid={weather_api_key}&units=metric"

# ThingSpeak setup
thingspeak_api_key = "C99GBY80UPVLAQFZ"
thingspeak_url = "https://api.thingspeak.com/update"

while True:
    # Step 1: Get weather data
    response = requests.get(weather_url)
    data = response.json()

    if response.status_code == 200:
        temp = data["main"]["temp"]
        humidity = data["main"]["humidity"]
        pressure = data["main"]["pressure"]
        wind_speed = data["wind"]["speed"]

        print(f"Temp: {temp} °C, Humidity: {humidity} %, Pressure: {pressure} hPa, Wind: {wind_speed} m/s")

        # Step 2: Send data to ThingSpeak
        payload = {
            'api_key': thingspeak_api_key,
            'field1': temp,
            'field2': humidity,
            'field3': pressure,
            'field4': wind_speed
        }

        upload = requests.post(thingspeak_url, params=payload)

        if upload.status_code == 200:
            print("✅ Data sent to ThingSpeak successfully.\n")
        else:
            print("❌ Failed to send data to ThingSpeak.\n")
    else:
        print("❌ Failed to fetch weather data.\n")

    # Wait for 1 minute (60 seconds)
    time.sleep(60)
