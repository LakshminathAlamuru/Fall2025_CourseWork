# IoT Assignment 3 - Spring 2025

This project simulates a cloud-based IoT system using virtual sensors that send data over MQTT and also to a Flask backend. The backend receives, stores, and displays the latest sensor data and historical temperature readings.

## Components

### `virtual_station.py`
- Simulates a virtual station with:
  - Temperature (-50 to 50°C)
  - Humidity (0 to 100%)
  - CO2 (300 to 2000 ppm)
- Sends data via:
  - MQTT to test.mosquitto.org
  - HTTP POST to a Flask server

### `backend_server.py`
- A Flask app that:
  - Receives sensor data (`/receive_data`)
  - Shows the latest sensor data from a station (`/latest/<station_id>`)
  - Shows historical temperature data for last 5 hours (`/history/temperature`)

## How to Run

### Start the Flask server:
```bash
python3 backend_server.py