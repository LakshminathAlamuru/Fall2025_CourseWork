import random
import time
import json
import paho.mqtt.client as mqtt
import requests

# Unique station ID
station_id = "station_1"

# MQTT broker settings
mqtt_broker = "test.mosquitto.org"
mqtt_port = 1883
mqtt_topic = f"iot/{station_id}/data"

# ThingSpeak settings
thingspeak_url = "https://api.thingspeak.com/update"
thingspeak_api_key = "MGXFXA402U03B76S"  

# Create MQTT client
client = mqtt.Client()
client.connect(mqtt_broker, mqtt_port)

def generate_sensor_data():
    return {
        "station_id": station_id,
        "timestamp": time.time(),
        "temperature": round(random.uniform(-50, 50), 2),
        "humidity": round(random.uniform(0, 100), 2),
        "co2": round(random.uniform(300, 2000), 2)
    }

# Loop to send data every 10 seconds
while True:
    sensor_data = generate_sensor_data()
    payload = json.dumps(sensor_data)

    # Send to MQTT
    client.publish(mqtt_topic, payload)
    print(f"Published to MQTT: {payload}")

    # Send to Flask backend
    try:
        response = requests.post("http://127.0.0.1:5000/receive_data", json=sensor_data)
        print(f"Sent to Flask: {response.status_code}")
    except Exception as e:
        print(f"Error sending to Flask: {e}")

    # Send to ThingSpeak
    try:
        thingspeak_payload = {
            "api_key": thingspeak_api_key,
            "field1": sensor_data["temperature"],
            "field2": sensor_data["humidity"],
            "field3": sensor_data["co2"]
        }
        ts_response = requests.post(thingspeak_url, params=thingspeak_payload)
        print(f"Sent to ThingSpeak: {ts_response.status_code}")
    except Exception as e:
        print(f"Error sending to ThingSpeak: {e}")

    time.sleep(10)