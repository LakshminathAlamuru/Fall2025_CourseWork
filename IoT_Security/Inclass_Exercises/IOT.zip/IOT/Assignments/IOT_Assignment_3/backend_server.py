from flask import Flask, request, jsonify
import time

app = Flask(__name__)

# In-memory list to store sensor data
data_store = []

@app.route('/receive_data', methods=['POST'])
def receive_data():
    data = request.get_json()
    data_store.append(data)
    return jsonify({"status": "received"}), 200

@app.route('/latest/<station_id>', methods=['GET'])
def get_latest_data(station_id):
    station_data = [d for d in data_store if d["station_id"] == station_id]
    if station_data:
        return jsonify(station_data[-1])
    return jsonify({"error": "No data found"}), 404

@app.route('/history/<sensor_name>', methods=['GET'])
def get_sensor_history(sensor_name):
    now = time.time()
    five_hours_ago = now - 5 * 3600
    filtered = [
        {"timestamp": d["timestamp"], sensor_name: d.get(sensor_name)}
        for d in data_store
        if d["timestamp"] >= five_hours_ago and sensor_name in d
    ]
    return jsonify(filtered)

if __name__ == '__main__':
    app.run(debug=True)