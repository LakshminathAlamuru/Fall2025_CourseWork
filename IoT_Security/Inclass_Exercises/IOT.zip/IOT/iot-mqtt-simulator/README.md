# IoT MQTT Simulator for AWS IoT Core

This project simulates a virtual IoT device publishing temperature and humidity data to AWS IoT Core using MQTT over TLS.

## Features
- Secure MQTT with X.509 certificates
- Simulated sensor values (temperature, humidity)
- Python-based, built with `paho-mqtt`
- MQTT messages routed via AWS IoT Rule to S3

## File(s)
- `mqtt_aws_simulator.py` – main script

> ❗ Note: TLS certs/keys (certificate.pem.crt, private.pem.key, etc.) are NOT included for security reasons.
