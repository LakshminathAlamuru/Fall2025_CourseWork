
import ssl
import time
import json
import random
import paho.mqtt.client as mqtt
AWS_ENDPOINT = "a3e3v462ne3a6w-ats.iot.us-east-1.amazonaws.com"
PORT = 8883
TOPIC = "update/environment/dht1"

CA_PATH = "AmazonRootCA1.pem"
CERT_PATH = "certificate.pem.crt"
KEY_PATH = "private.pem.key"

def generate_sensor_data():
    return json.dumps({
        "thingid": "dht1",
        "temperature": round(random.uniform(24.0, 30.0), 2),
        "humidity": round(random.uniform(40.0, 55.0), 2),
        "datetime": time.strftime("%Y-%m-%dT%H:%M:%S")
    })

client = mqtt.Client()
client.tls_set(ca_certs=CA_PATH,
               certfile=CERT_PATH,
               keyfile=KEY_PATH,
               tls_version=ssl.PROTOCOL_TLSv1_2)

try:
    client.connect(AWS_ENDPOINT, PORT)
    print("Connected to AWS IoT Core ✅")

    print("Publishing messages...")
    for _ in range(5):
        msg = generate_sensor_data()
        print("Sending:", msg)
        client.publish(TOPIC, msg, qos=1)
        time.sleep(2)

    client.disconnect()
    print("Disconnected ✅")

except Exception as e:
    print("❌ Error:", e)
